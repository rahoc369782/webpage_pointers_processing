package main

import "fmt"

func main() {
	str := "abkk.com"

	// 7 bytes

	runes := []rune(str)

	var result int

	for i := 0; i < len(runes); i++ {
		result = result + int(runes[i])
	}

	fmt.Println(result)
}
