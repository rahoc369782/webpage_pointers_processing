package fetcher

import (
	"log"
	"net/http"
)

// job type
type Job struct {
	Page_url string `json:"Url"`
	Owner    string `json:"Owner"`
}

// func Fetcher(payload *Job) (data *[]byte, err error) {
// 	resp, err := http.Get(payload.Page_url)
// 	if err != nil {
// 		log.Fatalln(err)
// 	}
// 	fmt.Println(resp.Body)
// 	body, err := ioutil.ReadAll(resp.Body)
// 	if err != nil {
// 		log.Fatalln(err)
// 	}
// 	return &body, nil

// }

func Fetcher(payload *Job) (res *http.Response, err error) {
	resp, err := http.Get(payload.Page_url)
	if err != nil {
		log.Fatalln(err)
	}
	return resp, nil
	// ioutil.WriteFile("data.txt", body, fs.ModeAppend.Perm())
	// //Convert the body to type string
	// log.Default()
	// extractor.Extract()
}
