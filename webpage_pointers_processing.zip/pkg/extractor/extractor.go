package extractor

import (
	"log"
	"net/http"

	"github.com/PuerkitoBio/goquery"
)

func Extract(res *http.Response) string {
	doc, err := goquery.NewDocumentFromResponse(res)
	if err != nil {
		log.Fatal(err)
	}

	// Find the review items
	doc.Find("a").Each(func(i int, s *goquery.Selection) {
		// For each item found, get the title
		for _, items := range s.Nodes {
			for i := 0; i < len(items.Attr); i++ {
				if items.Attr[i].Key == "href" {
					// fmt.Println(items.Attr[i].Val)
				}

			}
		}
	})
	return "Hello"
}
