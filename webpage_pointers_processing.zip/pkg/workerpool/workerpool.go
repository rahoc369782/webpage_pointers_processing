package workerpool

import (
	"fmt"
	"w_p_pr_service/pkg/extractor"
	"w_p_pr_service/pkg/fetcher"
)

type Workerpool interface {
	Run()
	QueueTask(task *fetcher.Job)
}

type workerpool struct {
	max_workers int
	job_queue   chan *fetcher.Job
}

func NewWWorkerPool(workers int, queue_length int) Workerpool {
	pool := &workerpool{
		max_workers: workers,
		job_queue:   make(chan *fetcher.Job, queue_length),
	}

	return pool
}

func (wp *workerpool) initialize_workers() {
	// start max workers into process

	for i := 0; i < wp.max_workers; i++ {
		go func(i int) {
			fmt.Println("started", i)
			task := <-wp.job_queue
			resp, err := fetcher.Fetcher(task)

			if err != nil {
				fmt.Println(err)
			}
			if resp != nil {
				extractor.Extract(resp)
			}
			fmt.Println("done by", i, task)
		}(i)
	}
}

func (wp *workerpool) queue_task(task *fetcher.Job) {
	// start max workers into process
	wp.job_queue <- task
}

func (wp *workerpool) Run() {
	wp.initialize_workers()
}

func (wp *workerpool) QueueTask(task *fetcher.Job) {
	wp.queue_task(task)
}
