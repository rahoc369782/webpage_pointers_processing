package storage

type HashStore interface {
	Add()
	Check()
}

type ScrapHashStore struct {
	urls map[string]bool
}

func (s *ScrapHashStore) Add(url string, exist bool) {

}

func (s *ScrapHashStore) Check(url string, exist bool) {

}

func CreateNewHashStore() HashStore {
	store := &ScrapHashStore{
		urls: map[string]bool{},
	}

	return store
}
