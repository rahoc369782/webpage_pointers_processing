package storage

import "fmt"

func hash_ascii() {
	c := 'A' // rune (characters in Go are represented using `rune` data type)
	asciiValue := int(c)
	fmt.Printf("Ascii Value of %c = %d\n", c, asciiValue)
}
