package main

import (
	"log"
	"net/http"
	"os"
	"w_p_pr_service/pkg/fetcher"
	"w_p_pr_service/pkg/workerpool"
)

var pool workerpool.Workerpool

func main() {

	pool = workerpool.NewWWorkerPool(1000, 1000)

	// Worker and Jobqueue Initiated
	pool.Run()

	log.Print("starting server...")
	http.HandleFunc("/process_pointer", handler)

	// Port for HTTP service.
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
		log.Printf("defaulting to port %s", port)
	}

	// Start HTTP server.
	log.Printf("listening on port %s", port)
	if err := http.ListenAndServe(":"+port, nil); err != nil {
		log.Fatal(err)
		return
	}
}

func handler(w http.ResponseWriter, r *http.Request) {
	// var ob fetcher.Job
	// err := json.NewDecoder(r.Body).Decode(&ob)
	// if err != nil {
	// 	http.Error(w, err.Error(), http.StatusBadRequest)
	// 	return
	// }
	// fmt.Println(ob)
	// if ob.Page_url != "" {
	// 	fmt.Println(ob)
	// 	pool.QueueTask(&ob)
	// }
	ob := fetcher.Job{
		Page_url: "https://www.educative.io/edpresso/how-to-make-http-post-request-with-json-body-in-golang",
		Owner:    "eihfiehf",
	}
	pool.QueueTask(&ob)
	w.Write([]byte("Hello"))
}
