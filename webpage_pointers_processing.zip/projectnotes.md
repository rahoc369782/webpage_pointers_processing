Webpage Pointers Processing Features

1) Request handler
2) Doc Fetcher
3) Renderer
4) Extractor (which extract all necessary nodes for pointers creation)
5) Pointer creation
6) Saver

- Threadpool (with fixed number of workers) which can handle all request async 

- Job queue for keeping track of pushed tasks
- 